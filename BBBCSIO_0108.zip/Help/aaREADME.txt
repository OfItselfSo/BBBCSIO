               BBBCSIO
  http://www.OfItselfSo.com/BBBCSIO/BBBCSIO.php

BBBCSIO is a C# I/O Library for the Beaglebone Black and is
Free and Open Source and released under the MIT License.

The start point for the documentation tree is the file in this
directory named: 

BBBCSIOHelp_TableOfContents.html